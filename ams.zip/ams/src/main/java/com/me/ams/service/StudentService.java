package com.me.ams.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.me.ams.entity.Student;
import com.me.ams.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
	StudentRepository studentRepository;
	
	public Integer saveStudent(Student student) {
		Student s = studentRepository.save(student);
		Integer stdId = s.getStdId();
		return stdId;
	}
	
	public List<Student> getAllStudent() {
		List<Student> student = studentRepository.findAll();
		return student;
	}
	
	public void deleteStudentById(Integer id) {
		studentRepository.deleteById(id);
	}
	@Transactional
	public void deleteStudentByEmail(String email) {
		studentRepository.deleteByEmail(email);
	}
	
	public Optional<Student> getOneStudent(Integer id) {
		return studentRepository.findById(id);
	}

	public Integer updateStudent(Student student) {
		Student e = studentRepository.save(student);
		Integer stdId = e.getStdId();
		return stdId;
	}

	public Student getOneStudentByEmail(String username) {
		return studentRepository.findByEmail(username);
	}
}
