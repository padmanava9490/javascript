package com.me.ams.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.me.ams.entity.Attendance;
import com.me.ams.model.AttendanceModel;
import com.me.ams.repository.AttendanceRepository;

@Service
public class AttendanceService {
	@Autowired
	AttendanceRepository attendanceRepository;
	
	public void addAttendance(List<Attendance> attendanceList) {
		attendanceRepository.saveAll(attendanceList);
	}
	
	/*public List<AttendanceModel> viewAllAttendance() {
		return attendanceRepository.findAllAttendance();
	}*/
	
	public List<Object[]> showAttendance(String dt, String branch, String semester, String subject) {
		return attendanceRepository.showAttendance(dt, branch, semester, subject);
	}
	
	public List<Object[]> showAttendanceByEmail(String email) {
		return attendanceRepository.showAttendanceByEmail(email);
	}
	@Transactional
	 public void deleteStudentByEmail(String email) {
		 attendanceRepository.deleteByEmail(email);
	 }
}
