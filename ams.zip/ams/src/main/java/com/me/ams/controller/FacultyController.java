package com.me.ams.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.me.ams.entity.Faculty;
import com.me.ams.entity.User;
import com.me.ams.model.FacultyModel;
import com.me.ams.service.FacultyService;
import com.me.ams.service.UserDetailsServiceImpl;

@Controller
@RequestMapping("faculty")
public class FacultyController {
	
	@Autowired
	FacultyService facultyService;
	
	@Autowired
	UserDetailsServiceImpl userService;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	
	@PostMapping("/save")
	public String registerStudent(@ModelAttribute FacultyModel facultyModel,Model model) {
		
		Faculty faculty = new Faculty();
		faculty.setFirstName(facultyModel.getFirstName());
		faculty.setLastName(facultyModel.getLastName());
		faculty.setEmail(facultyModel.getEmail());
		faculty.setPhoneNumber(facultyModel.getPhoneNumber());
		faculty.setAddress(facultyModel.getAddress());
		
		User user = new User();
		user.setEmail(facultyModel.getEmail());
		user.setPassword(passwordEncoder.encode(facultyModel.getPassword()));
		user.setRole("faculty");
		
		facultyService.saveFaculty(faculty);
		userService.saveUser(user);
		
		String message = "Faculty Registered Successfully";
		model.addAttribute("message",message);
		
		return "faculty-register";
	}
	
	@GetMapping("/faculty-home")
	public String getFacultyHome() {
		return "faculty-home";
	}
	
	@GetMapping("/delete")
	public String deleteFaculty(@RequestParam("id") Integer id,Model model) {
		return "show-faculty";
	}
}
