package com.me.ams.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.me.ams.entity.User;

public interface UserRepository  extends JpaRepository<User, Integer> {
    User findByEmail(String username);
    void deleteByEmail(String email);
}
