package com.me.ams.model;

import lombok.Data;

@Data
public class StudentModel {
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String phoneNumber;
    private String address;
}
