package com.me.ams.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.me.ams.entity.User;
import com.me.ams.service.UserDetailsServiceImpl;

//@Component
public class AdminRunner implements CommandLineRunner {

	@Autowired
	UserDetailsServiceImpl userDetailsServiceImpl;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Override
	public void run(String... args) throws Exception {
		User user = new User();
		user.setEmail("admin@gmail.com");
		user.setPassword(passwordEncoder.encode("12345"));
		user.setRole("admin");
		userDetailsServiceImpl.saveUser(user); 
	}

}
