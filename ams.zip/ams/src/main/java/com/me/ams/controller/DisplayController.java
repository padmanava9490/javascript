package com.me.ams.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/ams")
public class DisplayController {
	
	@GetMapping("/")
	public String landingPage() {
		return "index";
	}
	
	@GetMapping("/about")
	public String aboutPage() {
		return "about";
	}
	
	@GetMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	@GetMapping("/student-register")
	public String showRegisterPage() {
		return "student-register";
	}
	
	@RequestMapping("/login")
	public String getStudentLoginPage() {
		return "login";
	}
	
	@RequestMapping("/student-register")
	public String getStudentRegisterPage() {
		return "student-register";
	}
	
	
	@RequestMapping("/faculty-register")
	public String getFacultyRegisterPage() {
		return "faculty-register";
	}
}
