package com.me.ams.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.me.ams.entity.Attendance;
import com.me.ams.entity.Student;
import com.me.ams.entity.User;
import com.me.ams.model.AttendanceModel;
import com.me.ams.model.StudentModel;
import com.me.ams.service.AttendanceService;
import com.me.ams.service.StudentService;
import com.me.ams.service.UserDetailsServiceImpl;

@Controller
@RequestMapping("student")
public class StudentController {
	@Autowired
	StudentService studentService;
	@Autowired
	UserDetailsServiceImpl userService;
	@Autowired
	PasswordEncoder passwordEncoder;
	@Autowired
	AttendanceService attendanceService;
	
	@PostMapping("/save")
	public String registerStudent(@ModelAttribute StudentModel studentModel,Model model) {
		
		Student student = new Student();
		student.setFirstName(studentModel.getFirstName());
		student.setLastName(studentModel.getLastName());
		student.setEmail(studentModel.getEmail());
		student.setPhoneNumber(studentModel.getPhoneNumber());
		student.setAddress(studentModel.getAddress());
		
		User user = new User();
		user.setEmail(studentModel.getEmail());
		user.setPassword(passwordEncoder.encode(studentModel.getPassword()));
		user.setRole("student");
		
		studentService.saveStudent(student);
		userService.saveUser(user);
		
		String message = "Student Registered Successfully";
		model.addAttribute("message",message);
		
		return "student-register";
	}
	
	@GetMapping("/show")
	public String showStudents(Model model) {
		List<Student> students = studentService.getAllStudent();
		model.addAttribute("students",students);
		return "student-show";
	}
	
	
	@GetMapping("/home")
	public String showStudentsAttendance(Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String username = authentication.getName();
		User user = userService.findByEmail(username);
		
		if(user.getRole().trim().equals("student")) {
			Student student = studentService.getOneStudentByEmail(username);
			model.addAttribute("student",student);
			return "student-home";
		} if(user.getRole().trim().equals("faculty")) {
			return "faculty-home";
		}
		else {
			List<Student> students = studentService.getAllStudent();
			model.addAttribute("students",students);
			return "redirect:/admin/admin-home";
		}
		
	}

	@PostMapping("/save-attendance")
	public String saveStudentsAttendance(@RequestParam("ch") List<String> selectedEmail,
			@RequestParam("std_email") List<String> stdEmails,
			@RequestParam("dt") String dt,
			@RequestParam("branch") String branch,
			@RequestParam("semester") String semester,
			@RequestParam("subject") String subject,
			Model model) {
		
		List<Attendance> attendanceList = new ArrayList<Attendance>();
		
		for(String stdEmail : stdEmails) {
			Attendance ob = new Attendance();
			ob.setEmail(stdEmail);
			ob.setDateDt(dt);
			ob.setBranch(branch);
			ob.setSemester(semester);
			ob.setSubject(subject);
			
			if(selectedEmail.contains(stdEmail)) {
				ob.setStatus("p");
			} else {
				ob.setStatus("a");
			}
			attendanceList.add(ob);
		}
		attendanceService.addAttendance(attendanceList);
		
		List<Student> students = studentService.getAllStudent();
		model.addAttribute("students",students);
		model.addAttribute("message", "Attendance Added");
		return "student-attendance";
	}
	
	@GetMapping("/student-home")
	public String studentHomePage(Model model) {
		
		List<Student> students = studentService.getAllStudent();
		model.addAttribute("students",students);
		return "student-home";
	}
	
	
	
	@GetMapping("/show-attendance")
	public String addStudentAttendance(Model model) {
		
		List<Student> students = studentService.getAllStudent();
		model.addAttribute("students",students);
		return "student-attendance";
	}
	
	@GetMapping("/show-attendance-student")
	public String showStudentAttendance(Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String username = authentication.getName();
		
		List<Object[]> attendanceList = attendanceService.showAttendanceByEmail(username);
		List<AttendanceModel> studAttendanceList = new ArrayList<AttendanceModel>();
		for (Object[] row : attendanceList) {
		    String firstName = (String) row[0];
		    String lastName = (String) row[1];
		    String dt = (String) row[2];
		    String subject = (String) row[3];
		    String status = (String) row[4];
		    
		    AttendanceModel ob = new AttendanceModel();
		    ob.setFirstName(firstName);
		    ob.setLastName(lastName);
		    ob.setDate(dt);
		    ob.setSubject(subject);
		    ob.setStatus(status);
		    
		    studAttendanceList.add(ob);
		}
		model.addAttribute("attendanceList", studAttendanceList);
		return "show-attendance-student";
	}
	
}
