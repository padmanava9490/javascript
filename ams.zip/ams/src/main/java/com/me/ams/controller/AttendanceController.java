package com.me.ams.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.me.ams.entity.Attendance;
import com.me.ams.model.AttendanceModel;
import com.me.ams.service.AttendanceService;

@Controller
@RequestMapping("/attendance")
public class AttendanceController {
	@Autowired
	AttendanceService attendanceService;
	
	@GetMapping("/view-attendance")
	public String viewAttendance(Model model) {
		//List<AttendanceModel> attendanceList =  attendanceService.viewAllAttendance();
		//model.addAttribute("attendanceList", attendanceList);
		return "view-attendance";
	}
	
	@GetMapping("/show-attendance")
	public String showAttendance(@RequestParam("dt") String dt,
			@RequestParam("branch") String branch,
			@RequestParam("semester") String semester,
			@RequestParam("subject") String subject,
			Model model) {
		
		/*List<AttendanceModel> attendanceList =  attendanceService.viewAllAttendance();
		model.addAttribute("attendanceList", attendanceList);
		*/
		List<Object[]> attendanceList = attendanceService.showAttendance(dt, branch, semester, subject);
		List<AttendanceModel> studAttendanceList = new ArrayList<AttendanceModel>();
		for (Object[] row : attendanceList) {
		    String firstName = (String) row[0];
		    String lastName = (String) row[1];
		    String status = (String) row[2];
		    
		    AttendanceModel ob = new AttendanceModel();
		    ob.setFirstName(firstName);
		    ob.setLastName(lastName);
		    ob.setStatus(status);
		    studAttendanceList.add(ob);
		}
		model.addAttribute("attendanceList",studAttendanceList);
		return "view-attendance";
	}
}
