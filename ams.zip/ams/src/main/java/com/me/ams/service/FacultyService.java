package com.me.ams.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.me.ams.entity.Faculty;
import com.me.ams.repository.FacultyRepository;

@Service
public class FacultyService {
	@Autowired
	FacultyRepository facultyRepository;
	
	public Integer saveFaculty(Faculty faculty) {
		Faculty f = facultyRepository.save(faculty);
		Integer id = f.getId();
		return id;
	}
	
	public List<Faculty> getAllFaculty() {
		List<Faculty> faculty = facultyRepository.findAll();
		return faculty;
	}
	
	public void deleteFacultyById(Integer id) {
		facultyRepository.deleteById(id);
	}
	
	public Optional<Faculty> getFaculty(Integer id) {
		return facultyRepository.findById(id);
	}

	public Integer updateFaculty(Faculty faculty) {
		Faculty f = facultyRepository.save(faculty);
		Integer id = f.getId();
		return id;
	}
}
