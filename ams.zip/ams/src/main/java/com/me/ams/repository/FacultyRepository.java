package com.me.ams.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.me.ams.entity.Faculty;

public interface FacultyRepository extends JpaRepository<Faculty, Integer> {
	void deleteByEmail(String email);
}
