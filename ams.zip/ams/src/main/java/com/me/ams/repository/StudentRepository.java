package com.me.ams.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.me.ams.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	Student findByEmail(String email);
	void deleteByEmail(String email);
}
