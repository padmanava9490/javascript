package com.me.ams.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.me.ams.entity.Attendance;
import com.me.ams.model.AttendanceModel;

public interface AttendanceRepository extends JpaRepository<Attendance, Integer> {
	
	//@Query("SELECT NEW com.me.ams.model.AttendanceModel(s.firstName, a.status) FROM Attendance a INNER JOIN Student s ON a.email = s.email")
	//public List<AttendanceModel> findAllAttendance();
	
	@Query("SELECT s.firstName, s.lastName, a.status FROM Attendance a INNER JOIN Student s ON a.email = s.email "
			+ "WHERE a.dateDt= :dt  "
			+ "AND a.branch= :branch "
			+ "AND a.semester= :semester "
			+ "AND a.subject= :subject")
	public List<Object[]> showAttendance(String dt, String branch, String semester, String subject);

	@Query("SELECT s.firstName, s.lastName, a.dateDt, a.subject, a.status FROM Attendance a INNER JOIN Student s ON a.email = s.email "
			+ "WHERE a.email= :email  ")
	public List<Object[]> showAttendanceByEmail(String email);

	 void deleteByEmail(String email);
}
