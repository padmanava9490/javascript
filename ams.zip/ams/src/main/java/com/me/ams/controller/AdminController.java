package com.me.ams.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.me.ams.entity.Faculty;
import com.me.ams.entity.Student;
import com.me.ams.service.AttendanceService;
import com.me.ams.service.FacultyService;
import com.me.ams.service.StudentService;
import com.me.ams.service.UserDetailsServiceImpl;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	FacultyService facultyService;
	@Autowired 
	StudentService studentService;
	@Autowired
	UserDetailsServiceImpl userService;
	@Autowired
	AttendanceService attendanceService;
	
	@GetMapping("/show-faculty")
	public String showFaculty(Model model) {
		List<Faculty> facultyList = facultyService.getAllFaculty();
		model.addAttribute("facultyList",facultyList);
		return "show-faculty";
	}
	
	@GetMapping("/show-student")
	public String showStudent(Model model) {
		List<Student> students = studentService.getAllStudent();
		model.addAttribute("students",students);
		return "student-show";
	}
	
	@GetMapping("/admin-home")
	public String AdminHomePage(Model model) {
		return "admin-home";
	}
	
	@GetMapping("/student-delete")
	public String deleteEMployee(@RequestParam("email") String email,Model model) {
		studentService.deleteStudentByEmail(email);
		userService.deleteUserByEmail(email);
		attendanceService.deleteStudentByEmail(email);
		
		List<Student> students = studentService.getAllStudent();
		model.addAttribute("students",students);
		return "student-show";
	}

	@GetMapping("/student-edit")
	public String showEdit(@RequestParam("stdId") Integer stdId,Model model) {
		Optional<Student> student = studentService.getOneStudent(stdId);
		model.addAttribute("student",student);
		return "student-edit";
	}
	@PostMapping("/student-update")
	public String updateStudent(@ModelAttribute Student student ,Model model) {
		Integer stdId =  studentService.updateStudent(student);
		String message = "Student Updated, Id : "+stdId;
		
		List<Student> studList = studentService.getAllStudent();
		model.addAttribute("students",studList);
		model.addAttribute("message",message);
		return "student-show";
	}
	
	@GetMapping("/faculty-edit")
	public String showFaculyEditPage(@RequestParam("facultyId") Integer facultyId,Model model) {
		Optional<Faculty> faculty = facultyService.getFaculty(facultyId);
		model.addAttribute("faculty",faculty);
		return "faculty-edit";
	}
	
	@PostMapping("/faculty-update")
	public String updateFaculty(@ModelAttribute Faculty faculty ,Model model) {
		Integer facultId =  facultyService.updateFaculty(faculty);
		String message = "Student Updated";
		
		List<Faculty> facultyList = facultyService.getAllFaculty();
		model.addAttribute("facultyList",facultyList);
		model.addAttribute("message",message);
		return "show-faculty";
	}
	
	@GetMapping("/faculty-delete")
	public String deleteFaculty(@RequestParam("email") String email,Model model) {
		facultyService.deleteFacultyByEmail(email);
		userService.deleteUserByEmail(email);
		
		List<Faculty> facultyList = facultyService.getAllFaculty();
		model.addAttribute("facultyList",facultyList);
		return "show-faculty";
	}
}
